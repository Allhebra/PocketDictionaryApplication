package com.bereg.pocketdictionaryapplication.models.translation;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by 1 on 08.07.2018.
 */

class Body {

    @SerializedName("")
    @Expose
    List<AnyObj1> anyObj1s;
}

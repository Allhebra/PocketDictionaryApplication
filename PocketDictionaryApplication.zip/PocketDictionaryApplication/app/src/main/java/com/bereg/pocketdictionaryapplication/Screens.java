package com.bereg.pocketdictionaryapplication;

/**
 * Created by Aleksander Beregovoy on 14.07.2018.
 */

public class Screens {

    public final static String LOGIN_SCREEN = "login_screen";
    public final static String MINICARD_SCREEN = "minicard_screen";
    public final static String SAVED_MINICARDS_SCREEN = "saved_minicards_screen";
}

package com.bereg.pocketdictionaryapplication.presentation.views;

import com.arellomobile.mvp.MvpView;

/**
 * Created by 1 on 07.07.2018.
 */

public interface LoginView extends MvpView {
}

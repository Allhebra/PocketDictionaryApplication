package com.bereg.pocketdictionaryapplication.models.translation;

/**
 * Created by 1 on 12.07.2018.
 */

class AnyObj5 {
}

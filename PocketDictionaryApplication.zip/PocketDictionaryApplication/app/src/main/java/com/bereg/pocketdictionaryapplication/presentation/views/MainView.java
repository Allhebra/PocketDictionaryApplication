package com.bereg.pocketdictionaryapplication.presentation.views;

import com.arellomobile.mvp.MvpView;

/**
 * Created by 1 on 14.07.2018.
 */

public interface MainView extends MvpView {
}
